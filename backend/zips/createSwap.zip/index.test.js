"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_client_mock_1 = require("aws-sdk-client-mock");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const index_1 = require("./index");
const dynamoMock = (0, aws_sdk_client_mock_1.mockClient)(client_dynamodb_1.DynamoDBClient);
beforeEach(() => {
    dynamoMock.reset();
    process.env.SWAPS_TABLE = 'yogaswap-backend-demo-swaps-table';
});
describe('createSwap Lambda', () => {
    it('should create a new swap successfully', async () => {
        dynamoMock.on(client_dynamodb_1.PutItemCommand).resolves({});
        const event = {
            body: JSON.stringify({
                user: 'Luna',
                fromCourseId: 1,
                fromDate: '2025-10-01',
                toCourseId: 2,
                toDate: '2025-10-02',
                status: 'pending',
            }),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body)).toEqual({ message: 'Swap created' });
        expect(dynamoMock.calls()).toHaveLength(1);
        expect(dynamoMock.call(0).args[0].input).toMatchObject({
            TableName: 'yogaswap-backend-demo-swaps-table',
            Item: {
                swapId: { S: '2025-10-01#1#2025-10-02#2' },
                user: { S: 'Luna' },
                fromCourseId: { S: '1' },
                fromDate: { S: '2025-10-01' },
                toCourseId: { S: '2' },
                toDate: { S: '2025-10-02' },
                status: { S: 'pending' },
            },
        });
    });
    it('should return 400 for missing required fields', async () => {
        const event = {
            body: JSON.stringify({
                user: 'Luna',
                fromCourseId: 1,
                // fromDate, toCourseId, toDate, status fehlen
            }),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(400);
        expect(JSON.parse(result.body)).toEqual({ error: 'Missing required fields' });
        expect(dynamoMock.calls()).toHaveLength(0);
    });
    it('should handle DynamoDB errors', async () => {
        dynamoMock.on(client_dynamodb_1.PutItemCommand).rejects(new Error('DynamoDB failure'));
        const event = {
            body: JSON.stringify({
                user: 'Luna',
                fromCourseId: 1,
                fromDate: '2025-10-01',
                toCourseId: 2,
                toDate: '2025-10-02',
                status: 'pending',
            }),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(500);
        expect(JSON.parse(result.body)).toEqual({ error: 'Failed to create swap' });
        expect(dynamoMock.calls()).toHaveLength(1);
    });
    it('should return 500 for invalid JSON body', async () => {
        const event = {
            body: 'invalid-json',
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(500);
        expect(JSON.parse(result.body)).toEqual({ error: 'Failed to create swap' });
        expect(dynamoMock.calls()).toHaveLength(0);
    });
});
