"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
jest.mock('@aws-sdk/client-dynamodb', () => {
    const mockSend = jest.fn();
    return {
        DynamoDBClient: jest.fn(() => ({ send: mockSend })),
        PutItemCommand: jest.fn((input) => input),
        mockSend,
    };
});
const { mockSend } = jest.requireMock('@aws-sdk/client-dynamodb');
describe('createSwap Lambda', () => {
    const OLD_ENV = process.env;
    beforeEach(() => {
        jest.resetModules();
        process.env = { ...OLD_ENV, SWAPS_TABLE: 'test-swaps' };
        mockSend.mockReset();
    });
    afterAll(() => {
        process.env = OLD_ENV;
    });
    const baseEvent = (body) => ({
        body: JSON.stringify(body),
    });
    test('returns 400 if required fields are missing', async () => {
        const event = baseEvent({ user: 'Anna' }); // missing required fields
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(400);
        expect(JSON.parse(result.body).error).toMatch(/Missing required fields/);
        expect(mockSend).not.toHaveBeenCalled();
    });
    test('successfully creates a swap', async () => {
        mockSend.mockResolvedValueOnce({});
        const event = baseEvent({
            user: 'Nia',
            fromCourseId: 'c1',
            fromDate: '2025-10-01',
            toCourseId: 'c2',
            toDate: '2025-10-05',
            status: 'pending',
        });
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body).message).toBe('Swap created');
        expect(mockSend).toHaveBeenCalledWith(expect.objectContaining({
            TableName: 'test-swaps',
            Item: expect.objectContaining({
                user: { S: 'Nia' },
                fromCourseId: { S: 'c1' },
                toCourseId: { S: 'c2' },
                status: { S: 'pending' },
            }),
        }));
    });
    test('returns 500 if DynamoDB fails', async () => {
        mockSend.mockRejectedValueOnce(new Error('DynamoDB error'));
        const event = baseEvent({
            user: 'Nia',
            fromCourseId: 'c1',
            fromDate: '2025-10-01',
            toCourseId: 'c2',
            toDate: '2025-10-05',
            status: 'pending',
        });
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(500);
        expect(JSON.parse(result.body).error).toBe('Failed to create swap');
    });
});
