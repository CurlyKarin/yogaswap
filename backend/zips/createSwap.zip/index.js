"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: 'eu-central-1' });
const handler = async (event) => {
    const tableName = process.env.SWAPS_TABLE;
    const swap = event.body ? JSON.parse(event.body) : {};
    try {
        if (!swap.user || !swap.fromCourseId || !swap.fromDate || !swap.toCourseId || !swap.toDate || !swap.status) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Missing required fields' }) };
        }
        const dynamoItem = {
            swapId: { S: `${swap.fromDate}#${swap.fromCourseId}#${swap.toDate}#${swap.toCourseId}` },
            user: { S: swap.user },
            fromCourseId: { S: swap.fromCourseId.toString() },
            fromDate: { S: swap.fromDate },
            toCourseId: { S: swap.toCourseId.toString() },
            toDate: { S: swap.toDate },
            status: { S: swap.status },
            fromDate_fromCourseId_status: { S: `${swap.fromDate}#${swap.fromCourseId}#${swap.status}` },
            toDate_toCourseId_status: { S: `${swap.toDate}#${swap.toCourseId}#${swap.status}` },
        };
        await client.send(new client_dynamodb_1.PutItemCommand({ TableName: tableName, Item: dynamoItem }));
        return { statusCode: 200, body: JSON.stringify({ message: 'Swap created' }) };
    }
    catch (error) {
        console.error('Error creating swap:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to create swap' }) };
    }
};
exports.handler = handler;
