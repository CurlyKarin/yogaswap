"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: 'eu-central-1' });
const handler = async (event) => {
    const tableName = process.env.SWAPS_TABLE;
    const swapId = event.pathParameters?.swapId;
    try {
        if (!swapId) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Missing swapId' }) };
        }
        await client.send(new client_dynamodb_1.DeleteItemCommand({
            TableName: tableName,
            Key: { swapId: { S: swapId } },
        }));
        return { statusCode: 200, body: JSON.stringify({ message: 'Swap deleted' }) };
    }
    catch (error) {
        console.error(error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to delete swap' }) };
    }
};
exports.handler = handler;
