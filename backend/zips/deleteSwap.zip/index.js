"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: "eu-central-1" });
const handler = async (event) => {
    const swapId = event.pathParameters?.swapId;
    const user = event.queryStringParameters?.user;
    if (!swapId || !user) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Missing swapId or user parameter" }),
        };
    }
    const command = new client_dynamodb_1.DeleteItemCommand({
        TableName: process.env.SWAPS_TABLE,
        Key: {
            swapId: { S: swapId },
            user: { S: user },
        },
    });
    try {
        console.log('DeleteSwap command:', command.input);
        await client.send(command);
        console.log('DeleteSwap success:', { swapId, user });
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Swap deleted successfully" }),
        };
    }
    catch (err) {
        console.error('Error deleting swap:', err);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error" }),
        };
    }
};
exports.handler = handler;
