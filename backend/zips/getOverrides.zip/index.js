"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: "eu-central-1" });
const handler = async (event) => {
    // Optionaler Filter nach courseId
    const courseIdParam = event.queryStringParameters?.courseId;
    const courseId = courseIdParam ? Number(courseIdParam) : undefined;
    const command = new client_dynamodb_1.ScanCommand({
        TableName: process.env.OVERRIDES_TABLE,
    });
    try {
        const data = await client.send(command);
        let items = (data.Items || []).map((item) => ({
            courseId: Number(item.courseId.S),
            date: item.date.S,
            participants: JSON.parse(item.participants.S),
            swapped: item.swapped ? JSON.parse(item.swapped.S) : [],
            waitlist: item.waitlist ? JSON.parse(item.waitlist.S) : [],
        }));
        if (courseId !== undefined) {
            items = items.filter((c) => c.courseId === courseId);
        }
        return {
            statusCode: 200,
            body: JSON.stringify(items),
        };
    }
    catch (err) {
        console.error(err);
        return { statusCode: 500, body: "Internal Server Error" };
    }
};
exports.handler = handler;
