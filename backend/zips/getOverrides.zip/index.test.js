"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_client_mock_1 = require("aws-sdk-client-mock");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const index_1 = require("./index");
const dynamoMock = (0, aws_sdk_client_mock_1.mockClient)(client_dynamodb_1.DynamoDBClient);
beforeEach(() => {
    dynamoMock.reset();
    process.env.OVERRIDES_TABLE = 'yogaswap-backend-demo-courseOverrides-table';
});
describe('getOverrides Lambda', () => {
    it('should return all overrides', async () => {
        dynamoMock.on(client_dynamodb_1.ScanCommand).resolves({
            Items: [
                {
                    courseId: { S: '1' },
                    date: { S: '2025-10-01' },
                    participants: { S: JSON.stringify(['Luna']) },
                    swapped: { S: JSON.stringify([]) },
                    waitlist: { S: JSON.stringify([]) },
                },
            ],
        });
        const event = {
            queryStringParameters: {},
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body)).toEqual([
            {
                courseId: 1,
                date: '2025-10-01',
                participants: ['Luna'],
                swapped: [],
                waitlist: [],
            },
        ]);
        expect(dynamoMock.calls()).toHaveLength(1);
        expect(dynamoMock.call(0).args[0].input).toMatchObject({
            TableName: 'yogaswap-backend-demo-courseOverrides-table',
        });
    });
    it('should filter by courseId', async () => {
        dynamoMock.on(client_dynamodb_1.ScanCommand).resolves({
            Items: [
                {
                    courseId: { S: '1' },
                    date: { S: '2025-10-01' },
                    participants: { S: JSON.stringify(['Luna']) },
                    swapped: { S: JSON.stringify([]) },
                    waitlist: { S: JSON.stringify([]) },
                },
                {
                    courseId: { S: '2' },
                    date: { S: '2025-10-02' },
                    participants: { S: JSON.stringify(['Kai']) },
                    swapped: { S: JSON.stringify([]) },
                    waitlist: { S: JSON.stringify([]) },
                },
            ],
        });
        const event = {
            queryStringParameters: { courseId: '1' },
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body)).toEqual([
            {
                courseId: 1,
                date: '2025-10-01',
                participants: ['Luna'],
                swapped: [],
                waitlist: [],
            },
        ]);
    });
    it('should filter by sinceDate', async () => {
        dynamoMock.on(client_dynamodb_1.ScanCommand).resolves({
            Items: [
                {
                    courseId: { S: '1' },
                    date: { S: '2025-09-20' },
                    participants: { S: JSON.stringify(['Luna']) },
                    swapped: { S: JSON.stringify([]) },
                    waitlist: { S: JSON.stringify([]) },
                },
                {
                    courseId: { S: '1' },
                    date: { S: '2025-10-01' },
                    participants: { S: JSON.stringify(['Kai']) },
                    swapped: { S: JSON.stringify([]) },
                    waitlist: { S: JSON.stringify([]) },
                },
            ],
        });
        const event = {
            queryStringParameters: { sinceDate: '2025-09-30' },
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body)).toEqual([
            {
                courseId: 1,
                date: '2025-10-01',
                participants: ['Kai'],
                swapped: [],
                waitlist: [],
            },
        ]);
    });
    it('should handle DynamoDB errors', async () => {
        dynamoMock.on(client_dynamodb_1.ScanCommand).rejects(new Error('DynamoDB failure'));
        const event = {
            queryStringParameters: {},
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(500);
        expect(JSON.parse(result.body)).toEqual({ error: 'Internal Server Error' });
        expect(dynamoMock.calls()).toHaveLength(1);
    });
});
