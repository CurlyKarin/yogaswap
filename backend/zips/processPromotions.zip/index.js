"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: "eu-central-1" });
// Hardcodierter Zeitpuffer (in Minuten) vor Kursbeginn für Nachrücken
const PROMOTION_TIME_BUFFER_MINUTES = 30;
// Hilfsfunktion: Prüft, ob ein Kursbeginn mindestens PROMOTION_TIME_BUFFER_MINUTES in der Zukunft liegt
function isCourseInFuture(courseDate, courseTime, now) {
    try {
        // Kombiniere Datum (YYYY-MM-DD) und Uhrzeit (HH:mm) zu einem Date-Objekt
        const [year, month, day] = courseDate.split('-').map(Number);
        const [hours, minutes] = courseTime.split(':').map(Number);
        const courseStart = new Date(year, month - 1, day, hours, minutes);
        // Aktuelle Zeit + Puffer
        const bufferTime = new Date(now.getTime() + PROMOTION_TIME_BUFFER_MINUTES * 60 * 1000);
        // Prüfe, ob Kursbeginn nach bufferTime liegt
        return courseStart >= bufferTime;
    }
    catch (err) {
        console.error('Error parsing course date/time:', { courseDate, courseTime, error: err });
        return false; // Ignoriere ungültige Termine
    }
}
// Hilfsfunktion: Override aktualisieren
async function updateOverrideHelper(courseId, date, updates) {
    const updateExpressionParts = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};
    if (updates.participants) {
        updateExpressionParts.push("#participants = :participants");
        expressionAttributeNames["#participants"] = "participants";
        expressionAttributeValues[":participants"] = { L: updates.participants.map((p) => ({ S: p })) };
    }
    if (updates.swapped) {
        updateExpressionParts.push("#swapped = :swapped");
        expressionAttributeNames["#swapped"] = "swapped";
        expressionAttributeValues[":swapped"] = { L: updates.swapped.map((s) => ({ S: s })) };
    }
    if (updates.waitlist) {
        updateExpressionParts.push("#waitlist = :waitlist");
        expressionAttributeNames["#waitlist"] = "waitlist";
        expressionAttributeValues[":waitlist"] = { L: updates.waitlist.map((w) => ({ S: w })) };
    }
    if (updateExpressionParts.length === 0) {
        console.warn('No updates provided for override:', { courseId, date });
        return;
    }
    const command = new client_dynamodb_1.UpdateItemCommand({
        TableName: process.env.OVERRIDES_TABLE,
        Key: {
            courseId: { S: courseId.toString() },
            date: { S: date },
        },
        UpdateExpression: `SET ${updateExpressionParts.join(", ")}`,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: "ALL_NEW", // Für Debugging
    });
    try {
        const result = await client.send(command);
        console.log('updateOverrideHelper success:', {
            courseId,
            date,
            updates: Object.keys(updates),
            updatedAttributes: result.Attributes,
        });
    }
    catch (err) {
        console.error('Error updating override:', err);
        throw err;
    }
}
// Hilfsfunktion: Override erstellen
async function createOverrideHelper(override) {
    const command = new client_dynamodb_1.PutItemCommand({
        TableName: process.env.OVERRIDES_TABLE,
        Item: {
            courseId: { S: override.courseId.toString() },
            date: { S: override.date },
            participants: { L: (override.participants || []).map((p) => ({ S: p })) },
            swapped: { L: (override.swapped || []).map((s) => ({ S: s })) },
            waitlist: { L: (override.waitlist || []).map((w) => ({ S: w })) },
        },
    });
    try {
        console.log('createOverrideHelper command:', JSON.stringify(command.input, null, 2));
        await client.send(command);
        console.log('createOverrideHelper success:', { courseId: override.courseId, date: override.date });
    }
    catch (err) {
        console.error('Error creating override:', err);
        throw err;
    }
}
const handler = async (event) => {
    try {
        let body;
        if (!event.body) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Missing request body' }) };
        }
        body = JSON.parse(event.body);
        // Extrahiere currentUser (anpassen je nach Auth-Setup)
        const currentUser = event.requestContext?.authorizer?.principalId || body.currentUser || null;
        let iterations = 0;
        let changed = true;
        const maxIterations = 10;
        let promotedSwaps = [];
        while (changed && iterations < maxIterations) {
            changed = false;
            iterations++;
            // 1) Alle pending Swaps laden (Scan mit Filter)
            const pendingSwapsCommand = new client_dynamodb_1.ScanCommand({
                TableName: process.env.SWAPS_TABLE,
                FilterExpression: "#s = :s",
                ExpressionAttributeNames: { "#s": "status" },
                ExpressionAttributeValues: { ":s": { S: "pending" } },
                ConsistentRead: true,
            });
            const pendingSwapsData = await client.send(pendingSwapsCommand);
            const pendingSwaps = (pendingSwapsData.Items || []).map((item) => ({
                user: item.user.S,
                fromCourseId: Number(item.fromCourseId.N || item.fromCourseId.S),
                fromDate: item.fromDate.S,
                toCourseId: Number(item.toCourseId.N || item.toCourseId.S),
                toDate: item.toDate.S,
                status: item.status.S,
            }));
            console.log('pendingSwaps:', pendingSwaps);
            // 2) Alle Courses laden
            const coursesCommand = new client_dynamodb_1.ScanCommand({
                TableName: process.env.COURSES_TABLE,
                ConsistentRead: true,
            });
            const coursesData = await client.send(coursesCommand);
            const courses = (coursesData.Items || []).map((item) => ({
                id: Number(item.id.N),
                name: item.name.S,
                weekday: item.weekday.S,
                time: item.time.S,
                capacity: Number(item.capacity.N),
                participants: item.participants.L ? item.participants.L.map((p) => p.S) : [],
                dates: item.dates.L ? item.dates.L.map((d) => d.S) : [],
            }));
            console.log('courses:', courses);
            // 3) Alle Overrides laden
            const overridesCommand = new client_dynamodb_1.ScanCommand({
                TableName: process.env.OVERRIDES_TABLE,
                ConsistentRead: true,
            });
            const overridesData = await client.send(overridesCommand);
            const allOverrides = (overridesData.Items || []).map((item) => ({
                courseId: Number(item.courseId.S),
                date: item.date.S,
                participants: item.participants.L ? item.participants.L.map((p) => p.S) : [],
                swapped: item.swapped.L ? item.swapped.L.map((s) => s.S) : [],
                waitlist: item.waitlist.L ? item.waitlist.L.map((w) => w.S) : [],
            }));
            // Filtere Overrides: zukünftige Termine oder heutige Termine mit Puffer
            const now = new Date();
            const futureOverrides = allOverrides.filter((o) => {
                const course = courses.find((c) => c.id === o.courseId);
                if (!course)
                    return false;
                return isCourseInFuture(o.date, course.time, now);
            });
            console.log('futureOverrides:', futureOverrides);
            // 4) Durchsuche Overrides nach freien Plätzen mit Warteliste
            for (const override of futureOverrides) {
                console.log('override:', override);
                const overrideCourse = courses.find((c) => c.id === override.courseId);
                if (!overrideCourse)
                    continue;
                const freeSpots = overrideCourse.capacity - override.participants.length;
                console.log('freeSpots:', freeSpots);
                if (freeSpots <= 0)
                    continue;
                // Wähle promotedUser: Priorisiere currentUser oder erste Person
                let promotedUser;
                if (currentUser && override.waitlist?.includes(currentUser)) {
                    promotedUser = currentUser;
                }
                else {
                    promotedUser = override.waitlist?.[0];
                }
                if (!promotedUser)
                    continue;
                console.log('promotedUser:', promotedUser, 'override.courseId:', override.courseId, 'override.date:', override.date, 'override.waitlist:', override.waitlist);
                const correspondingSwap = pendingSwaps.find((s) => s.user === promotedUser && s.toCourseId === override.courseId && s.toDate === override.date);
                console.log('Find in pendingSwaps:', pendingSwaps, 'correspondingSwap:', correspondingSwap);
                if (!correspondingSwap)
                    continue;
                changed = true;
                promotedSwaps.push(correspondingSwap);
                // 5) Swap auf 'active' setzen
                const swapId = `${correspondingSwap.fromDate}_${correspondingSwap.fromCourseId}_${correspondingSwap.toDate}_${correspondingSwap.toCourseId}`;
                const updateSwapCommand = new client_dynamodb_1.UpdateItemCommand({
                    TableName: process.env.SWAPS_TABLE,
                    Key: {
                        swapId: { S: swapId },
                        user: { S: promotedUser },
                    },
                    UpdateExpression: "SET #status = :status, fromDate_fromCourseId_status = :fromStatus, toDate_toCourseId_status = :toStatus",
                    ExpressionAttributeNames: {
                        "#status": "status",
                    },
                    ExpressionAttributeValues: {
                        ":status": { S: "active" },
                        ":fromStatus": { S: `${correspondingSwap.fromDate}_${correspondingSwap.fromCourseId}_active` },
                        ":toStatus": { S: `${correspondingSwap.toDate}_${correspondingSwap.toCourseId}_active` },
                    },
                });
                await client.send(updateSwapCommand);
                console.log(`[processPromotions] Swap updated to active: ${swapId}`);
                // 6) Ziel-Override aktualisieren
                const newParticipants = [...override.participants, promotedUser].filter((p, i, arr) => arr.indexOf(p) === i); // Entferne Duplikate
                const newSwapped = [...(override.swapped || []), promotedUser].filter((p, i, arr) => arr.indexOf(p) === i);
                const newWaitlist = override.waitlist?.filter((u) => u !== promotedUser) || [];
                console.log('Updating target override:', {
                    courseId: override.courseId,
                    date: override.date,
                    newParticipants,
                    newSwapped,
                    newWaitlist,
                });
                await updateOverrideHelper(override.courseId, override.date, {
                    participants: newParticipants,
                    swapped: newSwapped,
                    waitlist: newWaitlist,
                });
                // 7) Ursprung-Override bereinigen
                const originOverride = allOverrides.find((o) => o.courseId === correspondingSwap.fromCourseId && o.date === correspondingSwap.fromDate);
                if (originOverride) {
                    const newOriginParticipants = originOverride.participants.includes(promotedUser)
                        ? originOverride.participants.filter((p) => p !== promotedUser)
                        : originOverride.participants;
                    const newOriginSwapped = (originOverride.swapped ?? []).filter((p) => p !== promotedUser);
                    const newOriginWaitlist = (originOverride.waitlist ?? []).filter((u) => u !== promotedUser);
                    console.log('Updating origin override:', {
                        courseId: correspondingSwap.fromCourseId,
                        date: correspondingSwap.fromDate,
                        newOriginParticipants,
                        newOriginSwapped,
                        newOriginWaitlist,
                    });
                    await updateOverrideHelper(correspondingSwap.fromCourseId, correspondingSwap.fromDate, {
                        participants: newOriginParticipants,
                        swapped: newOriginSwapped,
                        waitlist: newOriginWaitlist,
                    });
                }
                else {
                    const originCourse = courses.find((c) => c.id === correspondingSwap.fromCourseId);
                    if (originCourse && originCourse.participants.includes(promotedUser)) {
                        const newOriginOverride = {
                            courseId: correspondingSwap.fromCourseId,
                            date: correspondingSwap.fromDate,
                            participants: originCourse.participants.filter((p) => p !== promotedUser),
                            swapped: [],
                            waitlist: [],
                        };
                        console.log('Creating origin override:', newOriginOverride);
                        await createOverrideHelper(newOriginOverride);
                    }
                }
                // 8) Andere pending Swaps des Users stornieren
                const pendingOriginSwaps = pendingSwaps.filter((s) => s.user === promotedUser &&
                    s.fromCourseId === correspondingSwap.fromCourseId &&
                    s.fromDate === correspondingSwap.fromDate &&
                    (s.toCourseId !== correspondingSwap.toCourseId || s.toDate !== correspondingSwap.toDate));
                for (const originSwap of pendingOriginSwaps) {
                    const originSwapId = `${originSwap.fromDate}_${originSwap.fromCourseId}_${originSwap.toDate}_${originSwap.toCourseId}`;
                    const deleteCommand = new client_dynamodb_1.DeleteItemCommand({
                        TableName: process.env.SWAPS_TABLE,
                        Key: {
                            swapId: { S: originSwapId },
                            user: { S: promotedUser },
                        },
                    });
                    console.log('Deleting swap:', { originSwapId, user: promotedUser });
                    await client.send(deleteCommand);
                    const targetOriginOverride = allOverrides.find((o) => o.courseId === originSwap.toCourseId && o.date === originSwap.toDate);
                    if (targetOriginOverride) {
                        const newTargetWaitlist = (targetOriginOverride.waitlist || []).filter((u) => u !== promotedUser);
                        console.log('Updating target waitlist for cancelled swap:', {
                            courseId: originSwap.toCourseId,
                            date: originSwap.toDate,
                            newTargetWaitlist,
                        });
                        await updateOverrideHelper(originSwap.toCourseId, originSwap.toDate, {
                            waitlist: newTargetWaitlist,
                        });
                    }
                    console.log(`[processPromotions] Storniert pending Swap: ${originSwap.user} von ${originSwap.fromCourseId}/${originSwap.fromDate} → ${originSwap.toCourseId}/${originSwap.toDate}`);
                }
                console.log(`[processPromotions] ${promotedUser} nachgerückt von ${correspondingSwap.fromCourseId}/${correspondingSwap.fromDate} → ${override.courseId}/${override.date}`);
            }
            if (iterations >= maxIterations) {
                console.warn('[processPromotions] Max iterations reached - potential loop detected');
            }
        }
        // 9) Aktualisierte Swaps und Overrides laden
        const updatedSwapsCommand = new client_dynamodb_1.ScanCommand({
            TableName: process.env.SWAPS_TABLE,
            ConsistentRead: true,
        });
        const updatedSwapsData = await client.send(updatedSwapsCommand);
        const updatedSwaps = (updatedSwapsData.Items || []).map((item) => ({
            user: item.user.S,
            fromCourseId: Number(item.fromCourseId.N || item.fromCourseId.S),
            fromDate: item.fromDate.S,
            toCourseId: Number(item.toCourseId.N || item.toCourseId.S),
            toDate: item.toDate.S,
            status: item.status.S,
        }));
        const updatedOverridesCommand = new client_dynamodb_1.ScanCommand({
            TableName: process.env.OVERRIDES_TABLE,
            ConsistentRead: true,
        });
        const updatedOverridesData = await client.send(updatedOverridesCommand);
        const updatedOverrides = (updatedOverridesData.Items || []).map((item) => ({
            courseId: Number(item.courseId.S),
            date: item.date.S,
            participants: item.participants.L ? item.participants.L.map((p) => p.S) : [],
            swapped: item.swapped.L ? item.swapped.L.map((s) => s.S) : [],
            waitlist: item.waitlist.L ? item.waitlist.L.map((w) => w.S) : [],
        }));
        console.log(`[processPromotions] Complete after ${iterations} iterations`);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Promotions processed',
                iterations,
                promoted: promotedSwaps.length,
                swaps: updatedSwaps,
                overrides: updatedOverrides,
            }),
        };
    }
    catch (error) {
        console.error('Error in processPromotions:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to process promotions' })
        };
    }
};
exports.handler = handler;
