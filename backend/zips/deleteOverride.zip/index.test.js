"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("./index");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
// DynamoDB Mock Setup
jest.mock("@aws-sdk/client-dynamodb", () => {
    const mockSend = jest.fn();
    return {
        DynamoDBClient: jest.fn(() => ({ send: mockSend })),
        DeleteItemCommand: jest.fn((input) => input),
        mockSend,
    };
});
const { mockSend } = jest.requireMock("@aws-sdk/client-dynamodb");
describe("deleteOverride Lambda", () => {
    const OLD_ENV = process.env;
    beforeEach(() => {
        jest.resetModules();
        process.env = { ...OLD_ENV, OVERRIDES_TABLE: "test-overrides" };
        mockSend.mockReset();
    });
    afterAll(() => {
        process.env = OLD_ENV;
    });
    const makeEvent = (courseId, date) => ({
        pathParameters: courseId && date ? { courseId, date } : null,
    });
    test("returns 400 if courseId or date are missing", async () => {
        const event = makeEvent(undefined, undefined);
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(400);
        expect(JSON.parse(result.body).error).toBe("Missing courseId or date");
        expect(mockSend).not.toHaveBeenCalled();
    });
    test("deletes an override successfully", async () => {
        mockSend.mockResolvedValueOnce({});
        const event = makeEvent("course-123", "2025-10-01");
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body).message).toBe("Override deleted");
        expect(client_dynamodb_1.DeleteItemCommand).toHaveBeenCalledWith(expect.objectContaining({
            TableName: "test-overrides",
            Key: {
                courseId: { S: "course-123" },
                date: { S: "2025-10-01" },
            },
        }));
    });
    test("returns 500 on DynamoDB error", async () => {
        mockSend.mockRejectedValueOnce(new Error("DynamoDB error"));
        const event = makeEvent("course-123", "2025-10-01");
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(500);
        expect(JSON.parse(result.body).error).toBe("Failed to delete override");
    });
});
