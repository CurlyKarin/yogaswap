"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: 'eu-central-1' });
const handler = async (event) => {
    const tableName = process.env.OVERRIDES_TABLE;
    const courseId = event.pathParameters?.courseId;
    const date = event.pathParameters?.date;
    try {
        if (!courseId || !date) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Missing courseId or date' }) };
        }
        await client.send(new client_dynamodb_1.DeleteItemCommand({
            TableName: tableName,
            Key: {
                courseId: { S: courseId },
                date: { S: date },
            },
        }));
        return { statusCode: 200, body: JSON.stringify({ message: 'Override deleted' }) };
    }
    catch (error) {
        console.error('Error deleting override:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to delete override' }) };
    }
};
exports.handler = handler;
