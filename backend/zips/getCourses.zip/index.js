"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: 'eu-central-1' });
const handler = async (event) => {
    try {
        const result = await client.send(new client_dynamodb_1.ScanCommand({
            TableName: process.env.COURSES_TABLE,
            ConsistentRead: true,
        }));
        const courses = (result.Items || []).map((item) => ({
            id: Number(item.id.N),
            name: item.name.S,
            weekday: item.weekday.S,
            time: item.time.S,
            capacity: Number(item.capacity.N),
            participants: item.participants.L ? item.participants.L.map((p) => p.S) : [],
            dates: item.dates.L ? item.dates.L.map((d) => d.S) : [],
        }));
        return { statusCode: 200, body: JSON.stringify(courses) };
    }
    catch (error) {
        console.error('Error getting courses:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to get courses' }) };
    }
};
exports.handler = handler;
