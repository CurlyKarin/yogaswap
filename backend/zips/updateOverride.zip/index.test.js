"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_client_mock_1 = require("aws-sdk-client-mock");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const index_1 = require("./index");
const dynamoMock = (0, aws_sdk_client_mock_1.mockClient)(client_dynamodb_1.DynamoDBClient);
beforeEach(() => {
    dynamoMock.reset();
    process.env.OVERRIDES_TABLE = 'yogaswap-backend-demo-courseOverrides-table';
});
describe('updateOverride Lambda', () => {
    it('should update an override successfully', async () => {
        dynamoMock.on(client_dynamodb_1.UpdateItemCommand).resolves({});
        const event = {
            pathParameters: { courseId: '1', date: '2025-10-01' },
            body: JSON.stringify({
                participants: ['Luna', 'Kai'],
                swapped: ['Luna'],
            }),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(200);
        expect(JSON.parse(result.body)).toEqual({ message: 'Override updated' });
        expect(dynamoMock.calls()).toHaveLength(1);
        expect(dynamoMock.call(0).args[0].input).toMatchObject({
            TableName: 'yogaswap-backend-demo-courseOverrides-table',
            Key: { courseId: { S: '1' }, date: { S: '2025-10-01' } },
            UpdateExpression: 'SET #participants = :participants, #swapped = :swapped',
            ExpressionAttributeNames: {
                '#participants': 'participants',
                '#swapped': 'swapped',
            },
            ExpressionAttributeValues: {
                ':participants': { S: JSON.stringify(['Luna', 'Kai']) },
                ':swapped': { S: JSON.stringify(['Luna']) },
            },
        });
    });
    it('should return 400 for missing courseId or date', async () => {
        const event = {
            pathParameters: { courseId: '1' },
            body: JSON.stringify({ participants: ['Luna'] }),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(400);
        expect(JSON.parse(result.body)).toEqual({ error: 'Missing courseId or date' });
        expect(dynamoMock.calls()).toHaveLength(0);
    });
    it('should return 400 for no fields to update', async () => {
        const event = {
            pathParameters: { courseId: '1', date: '2025-10-01' },
            body: JSON.stringify({}),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(400);
        expect(JSON.parse(result.body)).toEqual({ error: 'No fields to update' });
        expect(dynamoMock.calls()).toHaveLength(0);
    });
    it('should handle DynamoDB errors', async () => {
        dynamoMock.on(client_dynamodb_1.UpdateItemCommand).rejects(new Error('DynamoDB failure'));
        const event = {
            pathParameters: { courseId: '1', date: '2025-10-01' },
            body: JSON.stringify({ participants: ['Luna'] }),
        };
        const result = await (0, index_1.handler)(event);
        expect(result.statusCode).toBe(500);
        expect(JSON.parse(result.body)).toEqual({ error: 'Failed to update override' });
        expect(dynamoMock.calls()).toHaveLength(1);
    });
});
