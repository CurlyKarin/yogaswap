"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: 'eu-central-1' });
const handler = async (event) => {
    const tableName = process.env.OVERRIDES_TABLE;
    const courseId = event.pathParameters?.courseId;
    const date = event.pathParameters?.date;
    const updates = JSON.parse(event.body || '{}');
    try {
        if (!courseId || !date) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Missing courseId or date' }) };
        }
        let updateExpression = 'SET';
        const expressionAttributeValues = {};
        const expressionAttributeNames = {};
        // Validierung und Mapping für participants
        if (updates.participants) {
            if (!Array.isArray(updates.participants) || updates.participants.some((p) => typeof p !== 'string')) {
                return { statusCode: 400, body: JSON.stringify({ error: 'Invalid participants array' }) };
            }
            updateExpression += ' #participants = :participants,';
            expressionAttributeNames['#participants'] = 'participants';
            expressionAttributeValues[':participants'] = { L: updates.participants.map((p) => ({ S: p })) };
        }
        // Validierung und Mapping für swapped
        if (updates.swapped) {
            if (!Array.isArray(updates.swapped) || updates.swapped.some((s) => typeof s !== 'string')) {
                return { statusCode: 400, body: JSON.stringify({ error: 'Invalid swapped array' }) };
            }
            updateExpression += ' #swapped = :swapped,';
            expressionAttributeNames['#swapped'] = 'swapped';
            expressionAttributeValues[':swapped'] = { L: updates.swapped.map((s) => ({ S: s })) };
        }
        // Validierung und Mapping für waitlist
        if (updates.waitlist) {
            if (!Array.isArray(updates.waitlist) || updates.waitlist.some((w) => typeof w !== 'string')) {
                return { statusCode: 400, body: JSON.stringify({ error: 'Invalid waitlist array' }) };
            }
            updateExpression += ' #waitlist = :waitlist,';
            expressionAttributeNames['#waitlist'] = 'waitlist';
            expressionAttributeValues[':waitlist'] = { L: updates.waitlist.map((w) => ({ S: w })) };
        }
        if (updateExpression === 'SET') {
            return { statusCode: 400, body: JSON.stringify({ error: 'No fields to update' }) };
        }
        updateExpression = updateExpression.slice(0, -1); // Entferne letztes Komma
        await client.send(new client_dynamodb_1.UpdateItemCommand({
            TableName: tableName,
            Key: { courseId: { S: courseId }, date: { S: date } },
            UpdateExpression: updateExpression,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
        }));
        return { statusCode: 200, body: JSON.stringify({ message: 'Override updated' }) };
    }
    catch (error) {
        console.error('Error updating override:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to update override' }) };
    }
};
exports.handler = handler;
