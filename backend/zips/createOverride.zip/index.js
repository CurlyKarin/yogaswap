"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: 'eu-central-1' });
const handler = async (event) => {
    const tableName = process.env.OVERRIDES_TABLE;
    const override = JSON.parse(event.body || '{}');
    try {
        if (!override.courseId || !override.date) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Missing courseId or date' }) };
        }
        // Validierung der Eingaben
        const participants = override.participants || [];
        const swapped = override.swapped || [];
        const waitlist = override.waitlist || [];
        if (!Array.isArray(participants) || participants.some((p) => typeof p !== 'string')) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Invalid participants array' }) };
        }
        if (!Array.isArray(swapped) || swapped.some((s) => typeof s !== 'string')) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Invalid swapped array' }) };
        }
        if (!Array.isArray(waitlist) || waitlist.some((w) => typeof w !== 'string')) {
            return { statusCode: 400, body: JSON.stringify({ error: 'Invalid waitlist array' }) };
        }
        const dynamoItem = {
            courseId: { S: override.courseId.toString() },
            date: { S: override.date },
            participants: { L: participants.map((p) => ({ S: p })) },
            swapped: { L: swapped.map((s) => ({ S: s })) },
            waitlist: { L: waitlist.map((w) => ({ S: w })) },
        };
        await client.send(new client_dynamodb_1.PutItemCommand({ TableName: tableName, Item: dynamoItem }));
        return { statusCode: 200, body: JSON.stringify({ message: 'Override created' }) };
    }
    catch (error) {
        console.error('Error creating override:', error);
        return { statusCode: 500, body: JSON.stringify({ error: 'Failed to create override' }) };
    }
};
exports.handler = handler;
