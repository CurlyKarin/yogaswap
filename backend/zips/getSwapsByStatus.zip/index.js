"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({ region: "eu-central-1" });
const handler = async (event) => {
    const status = event.queryStringParameters?.status;
    if (!status) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Missing status parameter' }) };
    }
    const command = new client_dynamodb_1.ScanCommand({
        TableName: process.env.SWAPS_TABLE,
        FilterExpression: "#s = :s",
        ExpressionAttributeNames: { "#s": "status" },
        ExpressionAttributeValues: { ":s": { S: status } },
        ConsistentRead: true,
    });
    try {
        console.log('getSwapsByStatus ScanCommand:', command.input);
        const data = await client.send(command);
        const items = (data.Items || []).map((item) => ({
            user: item.user.S,
            fromCourseId: Number(item.fromCourseId.S),
            fromDate: item.fromDate.S,
            toCourseId: Number(item.toCourseId.S),
            toDate: item.toDate.S,
            status: item.status.S,
        }));
        console.log('getSwapsByStatus result:', items);
        return { statusCode: 200, body: JSON.stringify(items) };
    }
    catch (err) {
        console.error('Error querying swaps by status:', err);
        return { statusCode: 500, body: JSON.stringify({ error: 'Internal Server Error' }) };
    }
};
exports.handler = handler;
