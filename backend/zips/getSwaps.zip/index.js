"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
//cd backend/src/lambdas/getSwaps
//npm init -y
//npm install typescript @types/node @aws-sdk/client-dynamodb aws-lambda --save-dev
const client = new client_dynamodb_1.DynamoDBClient({ region: "eu-central-1" });
const handler = async (event) => {
    const user = event.queryStringParameters?.user;
    if (!user) {
        return { statusCode: 400, body: "Missing 'user' query parameter" };
    }
    // Optional: Filter nach fromDate und fromCourseId
    const fromDate = event.queryStringParameters?.fromDate;
    const fromCourseId = event.queryStringParameters?.fromCourseId;
    // Range Key zusammengesetzt: "fromDate_fromCourseId"
    let keyCondition = "user = :u";
    const expressionValues = { ":u": { S: user } };
    if (fromDate && fromCourseId) {
        keyCondition += " AND fromDate_fromCourseId = :f";
        expressionValues[":f"] = { S: `${fromDate}#${fromCourseId}` };
    }
    const command = new client_dynamodb_1.QueryCommand({
        TableName: process.env.SWAPS_TABLE, // besser per ENV setzen!
        KeyConditionExpression: keyCondition,
        ExpressionAttributeValues: expressionValues,
    });
    try {
        const data = await client.send(command);
        const items = (data.Items || []).map((item) => {
            const [fDate, fCourseId] = item.fromDate_fromCourseId.S.split("_");
            return {
                user: item.user.S,
                fromCourseId: Number(fCourseId),
                fromDate: fDate,
                toCourseId: Number(item.toCourseId.N),
                toDate: item.toDate.S,
                status: item.status.S,
            };
        });
        return { statusCode: 200, body: JSON.stringify(items) };
    }
    catch (err) {
        console.error(err);
        return { statusCode: 500, body: "Internal Server Error" };
    }
};
exports.handler = handler;
