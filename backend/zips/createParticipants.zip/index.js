"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client_ses_1 = require("@aws-sdk/client-ses");
const cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({});
const ses = new client_ses_1.SESClient({});
const handler = async (event) => {
    const { email, nickname, role } = event;
    const tempPassword = Math.random().toString(36).slice(-8) + "A1!";
    try {
        // 1. User anlegen
        await cognito.send(new client_cognito_identity_provider_1.AdminCreateUserCommand({
            UserPoolId: process.env.USER_POOL_ID,
            Username: email,
            TemporaryPassword: tempPassword,
            UserAttributes: [
                { Name: "email", Value: email },
                { Name: "email_verified", Value: "true" },
                { Name: "custom:nickname", Value: nickname },
                { Name: "custom:role", Value: role },
            ],
            MessageAction: "SUPPRESS",
        }));
        // 2. In Gruppe
        await cognito.send(new client_cognito_identity_provider_1.AdminAddUserToGroupCommand({
            UserPoolId: process.env.USER_POOL_ID,
            Username: email,
            GroupName: role,
        }));
        // 3. Einladungslink
        const link = `https://yogaswap.de/invite?email=${encodeURIComponent(email)}&temp=${tempPassword}`;
        // 4. E-Mail
        await ses.send(new client_ses_1.SendEmailCommand({
            Source: "no-reply@yogaswap.de",
            Destination: { ToAddresses: [email] },
            Message: {
                Subject: { Data: "Willkommen bei YogaSwap!" },
                Body: { Html: { Data: `
          <h2>Hi ${nickname}!</h2>
          <p>Du wurdest zu YogaSwap eingeladen.</p>
          <p><a href="${link}">Klicke hier, um dein Passwort zu setzen</a></p>
          <p>Temporäres Passwort: <strong>${tempPassword}</strong> (nur falls Link nicht klappt)</p>
        ` } },
            },
        }));
        return { success: true };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
};
exports.handler = handler;
