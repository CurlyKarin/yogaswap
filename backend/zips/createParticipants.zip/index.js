"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const client_ses_1 = require("@aws-sdk/client-ses");
const cognito = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({});
const ses = new client_ses_1.SESClient({});
function generateSafeTempPassword(length = 10) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*";
    let pw = "";
    for (let i = 0; i < length; i++) {
        pw += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pw;
}
const handler = async (event) => {
    console.log('EVENT:', JSON.stringify(event));
    const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    const { email, nickname, role } = body;
    if (!email || !nickname || !role) {
        return { statusCode: 400, body: JSON.stringify({ error: "Missing required fields" }) };
    }
    // raw temporary password (safe characters)
    const rawPassword = generateSafeTempPassword(10) + "A1"; // ensure mix / length
    // Do NOT put the password in the URL; include in the email body only.
    // Use the nickname as Username (no suffix). If your pool is case-insensitive,
    // Cognito will internally normalize; at sign-in we normalize too (frontend).
    const username = nickname;
    try {
        // 1. User erstellen
        await cognito.send(new client_cognito_identity_provider_1.AdminCreateUserCommand({
            UserPoolId: process.env.USER_POOL_ID,
            Username: nickname, // Nickname muss einzigartig sein
            TemporaryPassword: rawPassword,
            UserAttributes: [
                { Name: "email", Value: email },
                { Name: "email_verified", Value: "true" },
                { Name: "nickname", Value: username },
                { Name: "custom:role", Value: role }
            ],
            MessageAction: "SUPPRESS", // Keine automatische E-Mail
        }));
    }
    catch (err) {
        // If user exists, set a new temporary password (so admin can re-invite)
        if (err?.name === "UsernameExistsException") {
            console.log("Username exists; setting a new temporary password via AdminSetUserPassword");
            try {
                await cognito.send(new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
                    UserPoolId: process.env.USER_POOL_ID,
                    Username: username,
                    Password: rawPassword,
                    Permanent: false // user must change on next sign-in
                }));
            }
            catch (err2) {
                console.error("AdminSetUserPassword failed:", err2);
                return { statusCode: 500, body: JSON.stringify({ error: "Failed to reset password" }) };
            }
        }
        else {
            console.error("AdminCreateUser failed:", err);
            return { statusCode: 500, body: JSON.stringify({ error: "Failed to create user" }) };
        }
    }
    // 2. Gruppe zuweisen
    try {
        await cognito.send(new client_cognito_identity_provider_1.AdminAddUserToGroupCommand({
            UserPoolId: process.env.USER_POOL_ID,
            Username: username,
            GroupName: role,
        }));
    }
    catch (err) {
        console.warn("Group assignment error (ignored):", err.message);
    }
    // Build link (only nickname in the URL)
    const baseUrlEnv = process.env.BASE_URL || "";
    const baseUrl = baseUrlEnv.startsWith("http") ? baseUrlEnv : `https://${baseUrlEnv}`;
    const link = `${baseUrl}/invite?nickname=${encodeURIComponent(username)}&email=${encodeURIComponent(email)}`;
    // Send invitation email (temp password shown in email body)
    const emailHtml = `
    <h2>Hi ${nickname}!</h2>
    <p>Du wurdest zu YogaSwap eingeladen.</p>
    <p><a href="${link}">Klicke hier, um dein temporäres Passwort einzugeben und ein neues Passwort zu setzen</a></p>
    <p><strong>Temporäres Passwort (bitte kopieren & einfügen):</strong>
      <br/><code style="background:#f0f0f0;padding:4px 8px;border-radius:4px;">${rawPassword}</code>
    </p>
    <p>Tipp: Falls das Passwort beim Einfügen nicht funktioniert, achte auf keine Leerzeichen vor/nach dem Passwort.</p>
  `;
    try {
        await ses.send(new client_ses_1.SendEmailCommand({
            Source: "karin.schrader@online.de",
            Destination: { ToAddresses: [email] },
            Message: {
                Subject: { Data: "YogaSwap Einladung" },
                Body: { Html: { Data: emailHtml } }
            }
        }));
    }
    catch (err) {
        console.warn("SES send warning:", err?.message || err);
        // do not fail user creation if SES can't send (depending on your policy)
    }
    console.log("createParticipants: created/updated username=", username);
    // Do NOT log passwords in production
    // console.log("createParticipants: rawPassword=", rawPassword);
    return { statusCode: 200, body: JSON.stringify({ success: true, username: username, link }) };
};
exports.handler = handler;
